# SSL Certificates

This directory contains SSL/TLS certificates for the Busibox deployment.

## File Naming Convention

### Production Certificates
```
{domain}.crt              # Certificate only
{domain}.key              # Private key (keep secure!)
{domain}.fullchain.crt    # Certificate + intermediate chain (recommended for nginx)
```

### Current Certificates

#### Wildcard Certificate for `*.ai.jaycashman.com`
- `ai.jaycashman.com.crt` - Certificate (covers *.ai.jaycashman.com and ai.jaycashman.com)
- `ai.jaycashman.com.key` - Private key
- `ai.jaycashman.com.fullchain.crt` - Full chain (recommended)

This wildcard certificate will work for:
- `staging.ai.jaycashman.com`
- `prod.ai.jaycashman.com`
- `test.ai.jaycashman.com`
- Any subdomain of `ai.jaycashman.com`

#### Local Development
- `localhost.crt` + `localhost.key` - Self-signed for local development

## How SSL Certificate Discovery Works

When deploying with Ansible, the nginx role automatically discovers SSL certificates:

1. **Exact match**: Looks for `{full_domain}.crt` + `{full_domain}.key`
   - Example: `staging.ai.jaycashman.com.crt`

2. **Wildcard match**: Extracts parent domain and looks for `{parent_domain}.crt` + `{parent_domain}.key`
   - Example: For `staging.ai.jaycashman.com`, looks for `ai.jaycashman.com.crt`

3. **Self-signed fallback**: If no certificates found, generates self-signed certificate

4. **Fullchain preference**: Uses `.fullchain.crt` if available, otherwise uses `.crt`

## Adding New Certificates

### For a new domain (e.g., example.com)
```bash
# Place your certificate files:
ssl/example.com.crt           # Certificate
ssl/example.com.key           # Private key (chmod 600!)
ssl/example.com.fullchain.crt # Full chain (optional but recommended)

# Set correct permissions
chmod 644 ssl/example.com.crt
chmod 600 ssl/example.com.key
chmod 644 ssl/example.com.fullchain.crt
```

### For a wildcard certificate (e.g., *.example.com)
```bash
# Use the parent domain name:
ssl/example.com.crt           # Covers *.example.com
ssl/example.com.key
ssl/example.com.fullchain.crt
```

## Security Notes

⚠️ **IMPORTANT**:
- **Private keys** (`.key` files) should NEVER be committed to git if public
- Private keys should have `chmod 600` (owner read/write only)
- This directory is currently **NOT** in `.gitignore` - be careful!

## Certificate Chain Files

The fullchain certificate should contain (in order):
1. Your domain certificate
2. Intermediate CA certificate(s)
3. Root CA certificate (optional)

Example:
```bash
cat ai.jaycashman.com.crt \
    SSL_WILDCARD_IntermediateCA_3.crt \
    SSL_WILDCARD_IntermediateCA_2.crt \
    SSL_WILDCARD_CertificateAuthorityRoot.crt \
    > ai.jaycashman.com.fullchain.crt
```

## Verification

Verify certificate matches private key:
```bash
# Get certificate modulus
openssl x509 -noout -modulus -in ai.jaycashman.com.crt | openssl md5

# Get key modulus
openssl rsa -noout -modulus -in ai.jaycashman.com.key | openssl md5

# Hashes should match!
```

Check certificate details:
```bash
# View certificate info
openssl x509 -in ai.jaycashman.com.crt -noout -text

# Check SAN (Subject Alternative Names) for wildcard
openssl x509 -in ai.jaycashman.com.crt -noout -text | grep -A2 "Subject Alternative Name"
```

## Let's Encrypt / Certbot (Future)

For automatic certificate generation and renewal, we can integrate Let's Encrypt:
```bash
# Example (not yet implemented)
certbot certonly --dns-cloudflare \
  --dns-cloudflare-credentials ~/.secrets/cloudflare.ini \
  -d "*.ai.jaycashman.com" \
  -d "ai.jaycashman.com"
```

This would automatically place certificates in the correct location and handle renewals.
